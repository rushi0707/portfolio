var typed=new Typed(".typing",{
    strings:["Developer","Designer","Coder"],
    typeSpeed: 100,
    backSpeed: 60,
    loop: true
});